Widgets I hope to implement (or at least investigate):

- NSTokenField
- NSSegmentedControl
- NSLevelIndicator
- NSPathControl
- NSSlider (Circular)
- NSSplitView
- NSTextFinder
- NSOutlineView in an NSScrollView (Source List)
- NSDrawer
- PDFView
- WebView
