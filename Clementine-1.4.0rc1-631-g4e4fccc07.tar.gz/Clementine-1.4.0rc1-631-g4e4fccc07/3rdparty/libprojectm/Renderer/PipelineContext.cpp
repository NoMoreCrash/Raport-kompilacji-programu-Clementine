/*
 * PipelineContext.cpp
 *
 *  Created on: Jun 22, 2008
 *      Author: pete
 */

#include "PipelineContext.hpp"

PipelineContext::PipelineContext() {}
PipelineContext::~PipelineContext() {}
